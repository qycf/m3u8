# 和彩云

由 [drive.caiyun.js](https://github.com/reruin/sharelist/tree/master/plugins/drive.caiyun.js) 插件实现。 
``` 挂载路径
//用户名/初始文件夹ID?password=密码 
```
建议```挂载路径留空```，ShareList将自动开启挂载向导，按指示填写用户名、密码、路径即可。

![caiyun.png](https://i.loli.net/2020/10/12/szrtkNywBXqY8Zn.png)

?> 如果不需要挂载彩云根目录，请指定一个路径，例如```/abc/def```。   