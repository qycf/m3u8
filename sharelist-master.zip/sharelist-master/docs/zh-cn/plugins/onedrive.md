# OneDrive

新版 [OneDrive V2](https://github.com/reruin/sharelist/tree/master/plugins/drive.onedrive.js) 插件提供多种方式的挂载，适用于 家庭版 和 商业版(企业版/教育版)。请将```挂载路径留空```，访问后会开启挂载向导，按提示操作即可。  

?> ShareList内置了应用ID和应用机密 用于自动挂载。感谢 [yushangcl](https://github.com/yushangcl]) 提供世纪互联挂载应用。   
  
!> 使用自己提供的应用ID 和 应用机密 时，请将```重定向URI```设置为
```https://reruin.github.io/sharelist/redirect.html```, [查看中转页的代码](https://github.com/reruin/reruin.github.io/blob/master/sharelist/redirect.html)
